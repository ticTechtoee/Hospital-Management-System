﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PhysicalExam
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.txtID = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtCardi = New System.Windows.Forms.RichTextBox()
        Me.txtLu = New System.Windows.Forms.Label()
        Me.RichTextBox7 = New System.Windows.Forms.RichTextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtGe = New System.Windows.Forms.RichTextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtR = New System.Windows.Forms.RichTextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.txtAb = New System.Windows.Forms.RichTextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtBreast = New System.Windows.Forms.RichTextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtChest = New System.Windows.Forms.RichTextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtLYM = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtHead = New System.Windows.Forms.RichTextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtSkin = New System.Windows.Forms.RichTextBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.txtID2 = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtOA = New System.Windows.Forms.RichTextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtDrug = New System.Windows.Forms.RichTextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtToba = New System.Windows.Forms.RichTextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.txtAlco = New System.Windows.Forms.RichTextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtDru = New System.Windows.Forms.RichTextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtOcc = New System.Windows.Forms.RichTextBox()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.txtFam = New System.Windows.Forms.RichTextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.txtHis = New System.Windows.Forms.RichTextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtPres = New System.Windows.Forms.RichTextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtGEN = New System.Windows.Forms.RichTextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Location = New System.Drawing.Point(12, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(916, 559)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txtID)
        Me.TabPage1.Controls.Add(Me.Label6)
        Me.TabPage1.Controls.Add(Me.txtCardi)
        Me.TabPage1.Controls.Add(Me.txtLu)
        Me.TabPage1.Controls.Add(Me.RichTextBox7)
        Me.TabPage1.Controls.Add(Me.Label8)
        Me.TabPage1.Controls.Add(Me.txtGe)
        Me.TabPage1.Controls.Add(Me.Label9)
        Me.TabPage1.Controls.Add(Me.txtR)
        Me.TabPage1.Controls.Add(Me.Label10)
        Me.TabPage1.Controls.Add(Me.txtAb)
        Me.TabPage1.Controls.Add(Me.Label4)
        Me.TabPage1.Controls.Add(Me.txtBreast)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.txtChest)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.txtLYM)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.txtHead)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.txtSkin)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Controls.Add(Me.Button4)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(908, 533)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "PHYSICAL EXAM"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'txtID
        '
        Me.txtID.Location = New System.Drawing.Point(396, 34)
        Me.txtID.Name = "txtID"
        Me.txtID.Size = New System.Drawing.Size(100, 20)
        Me.txtID.TabIndex = 53
        Me.txtID.Visible = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(520, 362)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(117, 20)
        Me.Label6.TabIndex = 52
        Me.Label6.Text = "Cardiovascular:"
        '
        'txtCardi
        '
        Me.txtCardi.Location = New System.Drawing.Point(643, 362)
        Me.txtCardi.Name = "txtCardi"
        Me.txtCardi.Size = New System.Drawing.Size(235, 76)
        Me.txtCardi.TabIndex = 51
        Me.txtCardi.Text = ""
        '
        'txtLu
        '
        Me.txtLu.AutoSize = True
        Me.txtLu.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLu.Location = New System.Drawing.Point(520, 280)
        Me.txtLu.Name = "txtLu"
        Me.txtLu.Size = New System.Drawing.Size(57, 20)
        Me.txtLu.TabIndex = 50
        Me.txtLu.Text = "Lungs:"
        '
        'RichTextBox7
        '
        Me.RichTextBox7.Location = New System.Drawing.Point(643, 280)
        Me.RichTextBox7.Name = "RichTextBox7"
        Me.RichTextBox7.Size = New System.Drawing.Size(235, 76)
        Me.RichTextBox7.TabIndex = 49
        Me.RichTextBox7.Text = ""
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(520, 198)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(76, 20)
        Me.Label8.TabIndex = 48
        Me.Label8.Text = "Genitalia:"
        '
        'txtGe
        '
        Me.txtGe.Location = New System.Drawing.Point(643, 198)
        Me.txtGe.Name = "txtGe"
        Me.txtGe.Size = New System.Drawing.Size(235, 76)
        Me.txtGe.TabIndex = 47
        Me.txtGe.Text = ""
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(520, 116)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(69, 20)
        Me.Label9.TabIndex = 46
        Me.Label9.Text = "Rectum:"
        '
        'txtR
        '
        Me.txtR.Location = New System.Drawing.Point(643, 116)
        Me.txtR.Name = "txtR"
        Me.txtR.Size = New System.Drawing.Size(235, 76)
        Me.txtR.TabIndex = 45
        Me.txtR.Text = ""
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(520, 34)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(82, 20)
        Me.Label10.TabIndex = 44
        Me.Label10.Text = "Abdomen:"
        '
        'txtAb
        '
        Me.txtAb.Location = New System.Drawing.Point(643, 34)
        Me.txtAb.Name = "txtAb"
        Me.txtAb.Size = New System.Drawing.Size(235, 76)
        Me.txtAb.TabIndex = 43
        Me.txtAb.Text = ""
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(33, 362)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(60, 20)
        Me.Label4.TabIndex = 42
        Me.Label4.Text = "Breast:"
        '
        'txtBreast
        '
        Me.txtBreast.Location = New System.Drawing.Point(146, 362)
        Me.txtBreast.Name = "txtBreast"
        Me.txtBreast.Size = New System.Drawing.Size(235, 76)
        Me.txtBreast.TabIndex = 41
        Me.txtBreast.Text = ""
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(33, 280)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(55, 20)
        Me.Label3.TabIndex = 40
        Me.Label3.Text = "Chest:"
        '
        'txtChest
        '
        Me.txtChest.Location = New System.Drawing.Point(146, 280)
        Me.txtChest.Name = "txtChest"
        Me.txtChest.Size = New System.Drawing.Size(235, 76)
        Me.txtChest.TabIndex = 39
        Me.txtChest.Text = ""
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(33, 198)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 20)
        Me.Label2.TabIndex = 38
        Me.Label2.Text = "LYMPH notes:"
        '
        'txtLYM
        '
        Me.txtLYM.Location = New System.Drawing.Point(146, 198)
        Me.txtLYM.Name = "txtLYM"
        Me.txtLYM.Size = New System.Drawing.Size(235, 76)
        Me.txtLYM.TabIndex = 37
        Me.txtLYM.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(33, 116)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(99, 20)
        Me.Label1.TabIndex = 36
        Me.Label1.Text = "Head-EENT:"
        '
        'txtHead
        '
        Me.txtHead.Location = New System.Drawing.Point(146, 116)
        Me.txtHead.Name = "txtHead"
        Me.txtHead.Size = New System.Drawing.Size(235, 76)
        Me.txtHead.TabIndex = 35
        Me.txtHead.Text = ""
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(33, 34)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(44, 20)
        Me.Label5.TabIndex = 34
        Me.Label5.Text = "Skin:"
        '
        'txtSkin
        '
        Me.txtSkin.Location = New System.Drawing.Point(146, 34)
        Me.txtSkin.Name = "txtSkin"
        Me.txtSkin.Size = New System.Drawing.Size(235, 76)
        Me.txtSkin.TabIndex = 33
        Me.txtSkin.Text = ""
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(737, 468)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(165, 59)
        Me.Button2.TabIndex = 30
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Button4
        '
        Me.Button4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Location = New System.Drawing.Point(6, 468)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(165, 59)
        Me.Button4.TabIndex = 32
        Me.Button4.Text = "BACK"
        Me.Button4.UseVisualStyleBackColor = False
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.txtID2)
        Me.TabPage2.Controls.Add(Me.Label11)
        Me.TabPage2.Controls.Add(Me.txtOA)
        Me.TabPage2.Controls.Add(Me.Label12)
        Me.TabPage2.Controls.Add(Me.txtDrug)
        Me.TabPage2.Controls.Add(Me.Label13)
        Me.TabPage2.Controls.Add(Me.txtToba)
        Me.TabPage2.Controls.Add(Me.Label14)
        Me.TabPage2.Controls.Add(Me.txtAlco)
        Me.TabPage2.Controls.Add(Me.Label15)
        Me.TabPage2.Controls.Add(Me.txtDru)
        Me.TabPage2.Controls.Add(Me.Label16)
        Me.TabPage2.Controls.Add(Me.txtOcc)
        Me.TabPage2.Controls.Add(Me.Label17)
        Me.TabPage2.Controls.Add(Me.txtFam)
        Me.TabPage2.Controls.Add(Me.Label18)
        Me.TabPage2.Controls.Add(Me.txtHis)
        Me.TabPage2.Controls.Add(Me.Label19)
        Me.TabPage2.Controls.Add(Me.txtPres)
        Me.TabPage2.Controls.Add(Me.Label20)
        Me.TabPage2.Controls.Add(Me.txtGEN)
        Me.TabPage2.Controls.Add(Me.Button1)
        Me.TabPage2.Controls.Add(Me.Button6)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.Size = New System.Drawing.Size(908, 533)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "PATIENT HISTORY"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'txtID2
        '
        Me.txtID2.Location = New System.Drawing.Point(412, 12)
        Me.txtID2.Name = "txtID2"
        Me.txtID2.Size = New System.Drawing.Size(100, 20)
        Me.txtID2.TabIndex = 75
        Me.txtID2.Visible = False
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(507, 363)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(135, 16)
        Me.Label11.TabIndex = 74
        Me.Label11.Text = "OTHER ALLERGIES:"
        '
        'txtOA
        '
        Me.txtOA.Location = New System.Drawing.Point(643, 362)
        Me.txtOA.Name = "txtOA"
        Me.txtOA.Size = New System.Drawing.Size(235, 76)
        Me.txtOA.TabIndex = 73
        Me.txtOA.Text = ""
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(507, 281)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(84, 32)
        Me.Label12.TabIndex = 72
        Me.Label12.Text = "DRUG" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ALLERGIES:"
        '
        'txtDrug
        '
        Me.txtDrug.Location = New System.Drawing.Point(643, 280)
        Me.txtDrug.Name = "txtDrug"
        Me.txtDrug.Size = New System.Drawing.Size(235, 76)
        Me.txtDrug.TabIndex = 71
        Me.txtDrug.Text = ""
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(507, 199)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(76, 16)
        Me.Label13.TabIndex = 70
        Me.Label13.Text = "TOBACCO:"
        '
        'txtToba
        '
        Me.txtToba.Location = New System.Drawing.Point(643, 198)
        Me.txtToba.Name = "txtToba"
        Me.txtToba.Size = New System.Drawing.Size(235, 76)
        Me.txtToba.TabIndex = 69
        Me.txtToba.Text = ""
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(507, 117)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(72, 32)
        Me.Label14.TabIndex = 68
        Me.Label14.Text = "ALCOHOL" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "(GM/DAY):"
        '
        'txtAlco
        '
        Me.txtAlco.Location = New System.Drawing.Point(643, 116)
        Me.txtAlco.Name = "txtAlco"
        Me.txtAlco.Size = New System.Drawing.Size(235, 76)
        Me.txtAlco.TabIndex = 67
        Me.txtAlco.Text = ""
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(507, 35)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(76, 32)
        Me.Label15.TabIndex = 66
        Me.Label15.Text = "DRUG" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "THERAPY:"
        '
        'txtDru
        '
        Me.txtDru.Location = New System.Drawing.Point(643, 34)
        Me.txtDru.Name = "txtDru"
        Me.txtDru.Size = New System.Drawing.Size(235, 76)
        Me.txtDru.TabIndex = 65
        Me.txtDru.Text = ""
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(20, 363)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(111, 48)
        Me.Label16.TabIndex = 64
        Me.Label16.Text = "OCCUPATION" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "AND" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "ENVIRONMENT:"
        '
        'txtOcc
        '
        Me.txtOcc.Location = New System.Drawing.Point(174, 362)
        Me.txtOcc.Name = "txtOcc"
        Me.txtOcc.Size = New System.Drawing.Size(235, 76)
        Me.txtOcc.TabIndex = 63
        Me.txtOcc.Text = ""
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(20, 281)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(71, 32)
        Me.Label17.TabIndex = 62
        Me.Label17.Text = "FAMILY" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "HISTORY:"
        '
        'txtFam
        '
        Me.txtFam.Location = New System.Drawing.Point(174, 280)
        Me.txtFam.Name = "txtFam"
        Me.txtFam.Size = New System.Drawing.Size(235, 76)
        Me.txtFam.TabIndex = 61
        Me.txtFam.Text = ""
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.Location = New System.Drawing.Point(20, 199)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(71, 32)
        Me.Label18.TabIndex = 60
        Me.Label18.Text = "PAST" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "HISTORY:"
        '
        'txtHis
        '
        Me.txtHis.Location = New System.Drawing.Point(174, 198)
        Me.txtHis.Name = "txtHis"
        Me.txtHis.Size = New System.Drawing.Size(235, 76)
        Me.txtHis.TabIndex = 59
        Me.txtHis.Text = ""
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(20, 117)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(88, 32)
        Me.Label19.TabIndex = 58
        Me.Label19.Text = "PRESENT" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "COMPLAINT:"
        '
        'txtPres
        '
        Me.txtPres.Location = New System.Drawing.Point(174, 116)
        Me.txtPres.Name = "txtPres"
        Me.txtPres.Size = New System.Drawing.Size(235, 76)
        Me.txtPres.TabIndex = 57
        Me.txtPres.Text = ""
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.Location = New System.Drawing.Point(20, 35)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(128, 32)
        Me.Label20.TabIndex = 56
        Me.Label20.Text = "GEN.DATA/" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "PATIENT PROFILE:"
        '
        'txtGEN
        '
        Me.txtGEN.Location = New System.Drawing.Point(174, 34)
        Me.txtGEN.Name = "txtGEN"
        Me.txtGEN.Size = New System.Drawing.Size(235, 76)
        Me.txtGEN.TabIndex = 55
        Me.txtGEN.Text = ""
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(737, 468)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(165, 59)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "SAVE"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Button6
        '
        Me.Button6.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Button6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button6.Location = New System.Drawing.Point(6, 468)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(165, 59)
        Me.Button6.TabIndex = 35
        Me.Button6.Text = "BACK"
        Me.Button6.UseVisualStyleBackColor = False
        '
        'PhysicalExam
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGreen
        Me.ClientSize = New System.Drawing.Size(940, 583)
        Me.Controls.Add(Me.TabControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "PhysicalExam"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "PhysicalExam"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.TabPage2.ResumeLayout(False)
        Me.TabPage2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents TabControl1 As TabControl
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents TabPage2 As TabPage
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents Button6 As Button
    Friend WithEvents Button4 As Button
    Friend WithEvents Label6 As Label
    Friend WithEvents txtCardi As RichTextBox
    Friend WithEvents txtLu As Label
    Friend WithEvents RichTextBox7 As RichTextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents txtGe As RichTextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents txtR As RichTextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents txtAb As RichTextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents txtBreast As RichTextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents txtChest As RichTextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents txtLYM As RichTextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents txtHead As RichTextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents txtSkin As RichTextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents txtOA As RichTextBox
    Friend WithEvents Label12 As Label
    Friend WithEvents txtDrug As RichTextBox
    Friend WithEvents Label13 As Label
    Friend WithEvents txtToba As RichTextBox
    Friend WithEvents Label14 As Label
    Friend WithEvents txtAlco As RichTextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents txtDru As RichTextBox
    Friend WithEvents Label16 As Label
    Friend WithEvents txtOcc As RichTextBox
    Friend WithEvents Label17 As Label
    Friend WithEvents txtFam As RichTextBox
    Friend WithEvents Label18 As Label
    Friend WithEvents txtHis As RichTextBox
    Friend WithEvents Label19 As Label
    Friend WithEvents txtPres As RichTextBox
    Friend WithEvents Label20 As Label
    Friend WithEvents txtGEN As RichTextBox
    Friend WithEvents txtID As TextBox
    Friend WithEvents txtID2 As TextBox
End Class
